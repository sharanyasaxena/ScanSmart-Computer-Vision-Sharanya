"""Quality analytics (Module 3b).

Computes objective metrics for every processed page so that the batch report
can tell the user which scans are good and which should be retaken.
"""

from dataclasses import dataclass, asdict

import cv2
import numpy as np

from .config import ScanConfig
from .logger import get_logger
from .transform import estimate_skew

log = get_logger(__name__)


@dataclass
class QualityMetrics:
    """Objective measurements of an output page."""

    sharpness: float        # variance of the Laplacian
    contrast: float         # RMS contrast (std-dev of intensities)
    brightness: float       # mean intensity, 0-255
    ink_ratio: float        # fraction of dark (text) pixels
    skew_deg: float         # residual rotation in degrees
    is_blurry: bool
    grade: str              # GOOD | FAIR | POOR

    def to_dict(self) -> dict:
        return asdict(self)


def sharpness_score(gray: np.ndarray) -> float:
    """Variance of the Laplacian - the standard focus measure."""
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def contrast_score(gray: np.ndarray) -> float:
    """RMS contrast: standard deviation of pixel intensities."""
    return float(gray.std())


def ink_ratio(gray: np.ndarray) -> float:
    """Fraction of pixels below Otsu's threshold, i.e. printed content."""
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return float(np.count_nonzero(binary == 0) / binary.size)


def grade_page(sharpness: float, contrast: float, confidence: float,
               config: ScanConfig) -> str:
    """Combine the metrics into a single human-readable grade."""
    if confidence < config.min_confidence or sharpness < config.blur_threshold * 0.5:
        return "POOR"
    if sharpness < config.blur_threshold or contrast < 30 or confidence < 0.55:
        return "FAIR"
    return "GOOD"


def analyse(image: np.ndarray, confidence: float,
            config: ScanConfig) -> QualityMetrics:
    """Measure the quality of a processed page."""
    gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    sharpness = sharpness_score(gray)
    contrast = contrast_score(gray)
    metrics = QualityMetrics(
        sharpness=round(sharpness, 2),
        contrast=round(contrast, 2),
        brightness=round(float(gray.mean()), 2),
        ink_ratio=round(ink_ratio(gray), 4),
        skew_deg=estimate_skew(gray),
        is_blurry=bool(sharpness < config.blur_threshold),
        grade=grade_page(sharpness, contrast, confidence, config),
    )
    log.info(
        "Quality: grade=%s sharpness=%.1f contrast=%.1f skew=%.2f deg",
        metrics.grade, metrics.sharpness, metrics.contrast, metrics.skew_deg,
    )
    return metrics
