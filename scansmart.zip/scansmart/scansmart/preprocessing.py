"""Pre-processing stage (Module 1).

Converts a raw photograph into an edge map that the detector can work with.
Concepts applied: colour-space conversion, CLAHE histogram equalisation,
edge-preserving bilateral filtering, Gaussian smoothing, automatic Canny
thresholding and morphological closing.
"""

from typing import Dict

import cv2
import numpy as np

from .config import ScanConfig
from .logger import get_logger

log = get_logger(__name__)


def to_grayscale(image: np.ndarray) -> np.ndarray:
    """Convert BGR to single-channel grayscale (no-op if already gray)."""
    if image.ndim == 2:
        return image.copy()
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


def equalize(gray: np.ndarray, config: ScanConfig) -> np.ndarray:
    """Contrast Limited Adaptive Histogram Equalisation.

    CLAHE is preferred over global equalisation because document photos are
    often lit unevenly (shadow on one half of the page).
    """
    clahe = cv2.createCLAHE(
        clipLimit=config.clahe_clip,
        tileGridSize=(config.clahe_grid, config.clahe_grid),
    )
    return clahe.apply(gray)


def denoise(gray: np.ndarray, config: ScanConfig) -> np.ndarray:
    """Edge-preserving smoothing followed by a light Gaussian blur.

    The bilateral filter removes paper texture and sensor noise while keeping
    the page border sharp, which is exactly what Canny needs.
    """
    filtered = cv2.bilateralFilter(
        gray, config.blur_kernel, config.bilateral_sigma, config.bilateral_sigma
    )
    return cv2.GaussianBlur(filtered, (config.blur_kernel, config.blur_kernel), 0)


def auto_canny(gray: np.ndarray, config: ScanConfig) -> np.ndarray:
    """Canny edge detection with thresholds derived from the image median.

    Hard-coded thresholds fail on dark or washed-out photos; deriving them
    from the median makes the detector illumination independent.
    """
    median = float(np.median(gray))
    lower = int(max(0, (1.0 - config.canny_sigma) * median))
    upper = int(min(255, (1.0 + config.canny_sigma) * median))
    if upper <= lower:                       # degenerate (almost flat) image
        lower, upper = 50, 150
    edges = cv2.Canny(gray, lower, upper)
    log.debug("Canny thresholds: %d / %d (median %.1f)", lower, upper, median)
    return edges


def close_gaps(edges: np.ndarray, config: ScanConfig) -> np.ndarray:
    """Morphological closing + dilation to join broken page borders."""
    k = config.morph_kernel
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel, iterations=2)
    return cv2.dilate(closed, kernel, iterations=1)


def build_edge_map(image: np.ndarray, config: ScanConfig) -> Dict[str, np.ndarray]:
    """Run the full pre-processing chain.

    Returns a dictionary with every intermediate stage so that the CLI can
    dump debug images and the report can show the pipeline visually.
    """
    gray = to_grayscale(image)
    equalized = equalize(gray, config)
    smoothed = denoise(equalized, config)
    edges = auto_canny(smoothed, config)
    closed = close_gaps(edges, config)
    return {
        "gray": gray,
        "equalized": equalized,
        "smoothed": smoothed,
        "edges": edges,
        "closed": closed,
    }
