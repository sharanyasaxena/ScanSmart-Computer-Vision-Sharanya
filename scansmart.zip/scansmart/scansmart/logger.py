"""Logging helper.

A single place to configure logging satisfies the non-functional
"logging & monitoring" requirement and keeps module code clean.
"""

import logging
import sys
from typing import Optional

_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)-22s | %(message)s"
_DATEFMT = "%H:%M:%S"


def setup_logging(verbose: bool = False, logfile: Optional[str] = None) -> None:
    """Configure the root logger once, for the whole application."""
    level = logging.DEBUG if verbose else logging.INFO
    handlers = [logging.StreamHandler(sys.stdout)]
    if logfile:
        handlers.append(logging.FileHandler(logfile, encoding="utf-8"))
    logging.basicConfig(
        level=level, format=_FORMAT, datefmt=_DATEFMT, handlers=handlers, force=True
    )


def get_logger(name: str) -> logging.Logger:
    """Return a module-scoped logger."""
    return logging.getLogger(name)
