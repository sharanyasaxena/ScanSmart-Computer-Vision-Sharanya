"""Image input/output helpers (Module 1 - acquisition).

Handles safe reading of image files, discovery of every image inside a
folder, and writing results back to disk. All filesystem access of the
project is funnelled through this module.
"""

import os
from typing import List, Tuple

import cv2
import numpy as np

from .config import ScanConfig
from .exceptions import ImageLoadError, ExportError
from .logger import get_logger

log = get_logger(__name__)


def load_image(path: str) -> np.ndarray:
    """Read an image from disk as a BGR array.

    Raises:
        ImageLoadError: if the path does not exist or cannot be decoded.
    """
    if not os.path.isfile(path):
        raise ImageLoadError(f"File does not exist: {path}")

    # np.fromfile + imdecode instead of imread so that non-ASCII paths work.
    try:
        buffer = np.fromfile(path, dtype=np.uint8)
        image = cv2.imdecode(buffer, cv2.IMREAD_COLOR)
    except Exception as exc:                      # pragma: no cover - rare
        raise ImageLoadError(f"Could not read {path}: {exc}") from exc

    if image is None or image.size == 0:
        raise ImageLoadError(f"Unsupported or corrupt image file: {path}")

    log.debug("Loaded %s with shape %s", os.path.basename(path), image.shape)
    return image


def discover_images(path: str, config: ScanConfig) -> List[str]:
    """Return a sorted list of image paths for a file or a directory."""
    if os.path.isfile(path):
        return [path]
    if not os.path.isdir(path):
        raise ImageLoadError(f"Input path not found: {path}")

    files = [
        os.path.join(path, name)
        for name in sorted(os.listdir(path))
        if name.lower().endswith(config.valid_extensions)
    ]
    if not files:
        raise ImageLoadError(f"No supported images found inside {path}")
    log.info("Discovered %d image(s) in %s", len(files), path)
    return files


def save_image(image: np.ndarray, path: str) -> str:
    """Write an image, creating parent folders when required."""
    folder = os.path.dirname(os.path.abspath(path))
    os.makedirs(folder, exist_ok=True)
    ok = cv2.imwrite(path, image)
    if not ok:
        raise ExportError(f"Failed to write image to {path}")
    log.debug("Saved %s", path)
    return path


def resize_to_height(image: np.ndarray, height: int) -> Tuple[np.ndarray, float]:
    """Resize preserving the aspect ratio.

    Returns:
        (resized image, scale factor) where original = resized * scale.
    """
    h, w = image.shape[:2]
    if h <= height:
        return image.copy(), 1.0
    scale = h / float(height)
    new_size = (max(1, int(round(w / scale))), height)
    resized = cv2.resize(image, new_size, interpolation=cv2.INTER_AREA)
    return resized, scale


def stack_side_by_side(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    """Build a before/after comparison image (used for screenshots)."""
    def to_bgr(img: np.ndarray) -> np.ndarray:
        return img if img.ndim == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

    left, right = to_bgr(left), to_bgr(right)
    height = max(left.shape[0], right.shape[0])

    def pad(img: np.ndarray) -> np.ndarray:
        scale = height / img.shape[0]
        resized = cv2.resize(img, (int(img.shape[1] * scale), height))
        return resized

    return np.hstack([pad(left), np.full((height, 12, 3), 230, np.uint8), pad(right)])
