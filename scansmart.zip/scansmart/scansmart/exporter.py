"""Export & reporting (Module 3c).

Writes processed pages to disk, bundles them into a single multi-page PDF and
produces machine-readable (JSON/CSV) batch reports.
"""

import csv
import json
import os
from typing import Dict, List

import cv2
import numpy as np

from .exceptions import ExportError
from .logger import get_logger

log = get_logger(__name__)

CSV_COLUMNS = [
    "source", "output", "status", "method", "confidence", "area_ratio",
    "grade", "sharpness", "contrast", "brightness", "skew_deg",
    "width", "height", "elapsed_ms", "error",
]


def export_pdf(images: List[np.ndarray], path: str) -> str:
    """Combine processed pages into one PDF (A4 pages, image fitted).

    reportlab is optional: if it is missing the caller gets a clear message
    instead of a traceback.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.utils import ImageReader
        from reportlab.pdfgen import canvas
    except ImportError as exc:                # pragma: no cover
        raise ExportError(
            "reportlab is required for PDF export (pip install reportlab)"
        ) from exc

    if not images:
        raise ExportError("Cannot build a PDF from an empty page list")

    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    page_w, page_h = A4
    pdf = canvas.Canvas(path, pagesize=A4)

    for image in images:
        rgb = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        scale = min((page_w - 40) / w, (page_h - 40) / h)
        draw_w, draw_h = w * scale, h * scale
        pdf.drawImage(
            ImageReader(_as_pil(rgb)),
            (page_w - draw_w) / 2, (page_h - draw_h) / 2,
            width=draw_w, height=draw_h,
        )
        pdf.showPage()

    pdf.save()
    log.info("PDF written: %s (%d page(s))", path, len(images))
    return path


def _as_pil(array: np.ndarray):
    """Convert a numpy array into a PIL image for reportlab."""
    from PIL import Image
    mode = "L" if array.ndim == 2 else "RGB"
    return Image.fromarray(array.astype(np.uint8), mode=mode)


def write_json_report(records: List[Dict], config_dict: Dict, path: str) -> str:
    """Persist the full batch report as JSON."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    payload = {
        "config": config_dict,
        "summary": summarise(records),
        "pages": records,
    }
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    log.info("JSON report written: %s", path)
    return path


def write_csv_report(records: List[Dict], path: str) -> str:
    """Persist a flat CSV report, convenient for spreadsheets."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS, extrasaction="ignore")
        writer.writeheader()
        for record in records:
            writer.writerow({key: record.get(key, "") for key in CSV_COLUMNS})
    log.info("CSV report written: %s", path)
    return path


def summarise(records: List[Dict]) -> Dict:
    """Aggregate statistics over a batch (the 'analytics' feature)."""
    total = len(records)
    ok = [r for r in records if r.get("status") == "ok"]
    grades = {"GOOD": 0, "FAIR": 0, "POOR": 0}
    for record in ok:
        grades[record.get("grade", "POOR")] = grades.get(record.get("grade", "POOR"), 0) + 1
    confidences = [r["confidence"] for r in ok if r.get("confidence") is not None]
    times = [r["elapsed_ms"] for r in records if r.get("elapsed_ms")]
    return {
        "total_images": total,
        "processed": len(ok),
        "failed": total - len(ok),
        "success_rate": round(len(ok) / total, 3) if total else 0.0,
        "grades": grades,
        "mean_confidence": round(float(np.mean(confidences)), 3) if confidences else 0.0,
        "mean_time_ms": round(float(np.mean(times)), 1) if times else 0.0,
    }
