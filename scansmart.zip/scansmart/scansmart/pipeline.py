"""Pipeline orchestrator.

Wires the three functional modules together and provides the two public
entry points used by the CLI: `process_image` (single page) and
`process_batch` (folder of pages).
"""

import os
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from .config import ScanConfig
from .detector import Detection, detect_document, draw_detection
from .enhancement import enhance
from .exceptions import ScanSmartError
from .io_utils import (
    discover_images, load_image, resize_to_height, save_image, stack_side_by_side,
)
from .logger import get_logger
from .quality import QualityMetrics, analyse
from .transform import deskew, estimate_skew, four_point_transform

log = get_logger(__name__)


@dataclass
class PageResult:
    """Everything the pipeline produces for one input image."""

    source: str
    status: str = "ok"                       # "ok" | "failed"
    output: Optional[str] = None
    error: Optional[str] = None
    elapsed_ms: float = 0.0
    detection: Optional[Detection] = None
    metrics: Optional[QualityMetrics] = None
    image: Optional[np.ndarray] = field(default=None, repr=False)
    overlay: Optional[np.ndarray] = field(default=None, repr=False)

    def to_record(self) -> Dict:
        """Flatten into a dictionary for the CSV/JSON reports."""
        record: Dict = {
            "source": os.path.basename(self.source),
            "status": self.status,
            "output": os.path.basename(self.output) if self.output else "",
            "error": self.error or "",
            "elapsed_ms": round(self.elapsed_ms, 1),
        }
        if self.detection is not None:
            record.update(
                method=self.detection.method,
                confidence=self.detection.confidence,
                area_ratio=self.detection.area_ratio,
            )
        if self.metrics is not None:
            record.update(self.metrics.to_dict())
        if self.image is not None:
            record.update(height=int(self.image.shape[0]), width=int(self.image.shape[1]))
        return record


def process_image(path: str, config: ScanConfig,
                  auto_deskew: bool = True) -> PageResult:
    """Run the full pipeline on a single image.

    Steps: load -> downscale -> detect -> warp -> deskew -> enhance -> measure.
    Any ScanSmartError is captured so that a batch never aborts halfway.
    """
    start = time.perf_counter()
    result = PageResult(source=path)
    try:
        original = load_image(path)
        working, scale = resize_to_height(original, config.working_height)

        detection = detect_document(working, config, scale=scale)
        result.detection = detection
        result.overlay = draw_detection(original, detection)

        warped = four_point_transform(original, detection.corners, config)

        if auto_deskew:
            gray = warped if warped.ndim == 2 else warped[:, :, 0]
            angle = estimate_skew(gray)
            if abs(angle) > 0.3:
                log.debug("Deskewing by %.2f degrees", angle)
                warped = deskew(warped, angle)

        processed = enhance(warped, config)
        result.image = processed
        result.metrics = analyse(processed, detection.confidence, config)

    except ScanSmartError as exc:
        result.status, result.error = "failed", str(exc)
        log.error("%s -> %s", os.path.basename(path), exc)
    except Exception as exc:                  # unexpected: log, do not crash
        result.status, result.error = "failed", f"unexpected: {exc}"
        log.exception("Unexpected failure on %s", path)

    result.elapsed_ms = (time.perf_counter() - start) * 1000.0
    return result


def process_batch(input_path: str, output_dir: str, config: ScanConfig,
                  save_overlay: bool = False,
                  save_comparison: bool = False) -> List[PageResult]:
    """Process every image found at `input_path` and write the outputs."""
    paths = discover_images(input_path, config)
    os.makedirs(output_dir, exist_ok=True)
    results: List[PageResult] = []

    for index, path in enumerate(paths, start=1):
        log.info("[%d/%d] Processing %s", index, len(paths), os.path.basename(path))
        result = process_image(path, config)

        if result.status == "ok" and result.image is not None:
            stem = os.path.splitext(os.path.basename(path))[0]
            result.output = save_image(
                result.image, os.path.join(output_dir, f"{stem}_scanned.png")
            )
            if save_overlay and result.overlay is not None:
                save_image(result.overlay,
                           os.path.join(output_dir, f"{stem}_detected.png"))
            if save_comparison:
                save_image(
                    stack_side_by_side(load_image(path), result.image),
                    os.path.join(output_dir, f"{stem}_comparison.png"),
                )
        results.append(result)

    return results
