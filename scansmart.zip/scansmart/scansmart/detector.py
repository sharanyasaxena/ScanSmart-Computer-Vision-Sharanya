"""Document detection (Module 2).

Finds the four corners of the page inside the photograph using a three-level
strategy, so that the system degrades gracefully instead of crashing:

    1. Contour approximation  - Douglas-Peucker on the largest contours.
    2. Rotated bounding box   - Otsu threshold + minAreaRect fallback.
    3. Whole-frame rectangle  - last resort, flagged with zero confidence.
"""

from dataclasses import dataclass
from typing import List, Optional

import cv2
import numpy as np

from .config import ScanConfig
from .exceptions import DocumentNotFoundError
from .logger import get_logger
from .preprocessing import build_edge_map, to_grayscale

log = get_logger(__name__)


@dataclass
class Detection:
    """Result of the detection stage."""

    corners: np.ndarray        # (4, 2) float32, in ORIGINAL image coordinates
    method: str                # "contour" | "min_area_rect" | "full_frame"
    confidence: float          # 0.0 - 1.0
    area_ratio: float          # page area / image area


# ---------------------------------------------------------------- helpers
def order_corners(points: np.ndarray) -> np.ndarray:
    """Order 4 points as top-left, top-right, bottom-right, bottom-left.

    Uses the classic sum/difference trick: the top-left corner has the
    smallest x+y, the bottom-right the largest; the top-right has the
    smallest y-x.
    """
    pts = np.asarray(points, dtype="float32").reshape(4, 2)
    ordered = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    d = np.diff(pts, axis=1).ravel()
    ordered[0] = pts[np.argmin(s)]     # top-left
    ordered[2] = pts[np.argmax(s)]     # bottom-right
    ordered[1] = pts[np.argmin(d)]     # top-right
    ordered[3] = pts[np.argmax(d)]     # bottom-left
    return ordered


def _angle_score(corners: np.ndarray) -> float:
    """Score how close the quadrilateral is to a real (rectangular) page.

    A perspective view of a rectangle keeps interior angles reasonably near
    90 degrees; random blobs do not. Returns 1.0 for a perfect rectangle.
    """
    c = order_corners(corners)
    deviations = []
    for i in range(4):
        prev_v = c[(i - 1) % 4] - c[i]
        next_v = c[(i + 1) % 4] - c[i]
        n1 = np.linalg.norm(prev_v) + 1e-6
        n2 = np.linalg.norm(next_v) + 1e-6
        cosine = float(np.dot(prev_v, next_v) / (n1 * n2))
        angle = np.degrees(np.arccos(np.clip(cosine, -1.0, 1.0)))
        deviations.append(abs(angle - 90.0))
    mean_dev = float(np.mean(deviations))
    return float(max(0.0, 1.0 - mean_dev / 45.0))


def _is_valid_quad(corners: np.ndarray, image_area: float,
                   config: ScanConfig) -> bool:
    """Reject quadrilaterals that are too small, too big or not convex."""
    quad = order_corners(corners).astype(np.int32)
    area = abs(cv2.contourArea(quad))
    ratio = area / float(image_area)
    if not config.min_area_ratio <= ratio <= config.max_area_ratio:
        return False
    return bool(cv2.isContourConvex(quad))


# ---------------------------------------------------------------- strategies
def _find_by_contour(edge_map: np.ndarray, config: ScanConfig) -> Optional[np.ndarray]:
    """Strategy 1: largest 4-point polygon obtained by contour approximation."""
    contours, _ = cv2.findContours(
        edge_map, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
    )
    if not contours:
        return None

    contours = sorted(contours, key=cv2.contourArea, reverse=True)[: config.top_contours]
    image_area = float(edge_map.shape[0] * edge_map.shape[1])

    best, best_score = None, -1.0
    eps_values = np.arange(
        config.approx_eps_start, config.approx_eps_end, config.approx_eps_step
    )
    for contour in contours:
        perimeter = cv2.arcLength(contour, True)
        if perimeter < 50:
            continue
        for eps in eps_values:
            approx = cv2.approxPolyDP(contour, eps * perimeter, True)
            if len(approx) != 4:
                continue
            quad = approx.reshape(4, 2).astype("float32")
            if not _is_valid_quad(quad, image_area, config):
                continue
            area_ratio = abs(cv2.contourArea(order_corners(quad))) / image_area
            # Prefer large, rectangle-like candidates.
            score = 0.6 * _angle_score(quad) + 0.4 * area_ratio
            if score > best_score:
                best, best_score = quad, score
            break                      # first eps that yields a quad is enough
    return best


def _find_by_min_area_rect(gray: np.ndarray, config: ScanConfig) -> Optional[np.ndarray]:
    """Strategy 2: Otsu binarisation + rotated bounding box of the biggest blob."""
    blurred = cv2.GaussianBlur(gray, (config.blur_kernel, config.blur_kernel), 0)
    _, binary = cv2.threshold(
        blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )
    # The page is usually brighter than the background; if not, invert.
    if np.mean(binary) < 127:
        binary = cv2.bitwise_not(binary)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (9, 9))
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)

    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    largest = max(contours, key=cv2.contourArea)
    image_area = float(gray.shape[0] * gray.shape[1])
    box = cv2.boxPoints(cv2.minAreaRect(largest)).astype("float32")
    if not _is_valid_quad(box, image_area, config):
        return None
    return box


def _full_frame(shape) -> np.ndarray:
    """Strategy 3: assume the whole photograph is the document."""
    h, w = shape[:2]
    return np.array(
        [[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]], dtype="float32"
    )


# ---------------------------------------------------------------- public API
def detect_document(image: np.ndarray, config: ScanConfig,
                    scale: float = 1.0,
                    allow_fallback: bool = True) -> Detection:
    """Locate the document corners inside `image`.

    Args:
        image: the (already down-scaled) working image.
        config: pipeline configuration.
        scale: factor to map coordinates back to the original resolution.
        allow_fallback: if False, raise instead of returning a full-frame quad.

    Raises:
        DocumentNotFoundError: when nothing is found and fallback is disabled.
    """
    stages = build_edge_map(image, config)
    gray = stages["gray"]
    image_area = float(image.shape[0] * image.shape[1])

    corners = _find_by_contour(stages["closed"], config)
    method = "contour"

    if corners is None:
        log.debug("Contour strategy failed, trying minAreaRect fallback")
        corners = _find_by_min_area_rect(gray, config)
        method = "min_area_rect"

    if corners is None:
        if not allow_fallback:
            raise DocumentNotFoundError("No document-like quadrilateral found")
        log.warning("Detection failed - falling back to the full frame")
        corners = _full_frame(image.shape)
        method = "full_frame"

    ordered = order_corners(corners)
    area_ratio = abs(cv2.contourArea(ordered.astype(np.int32))) / image_area

    if method == "full_frame":
        confidence = 0.0
    else:
        base = {"contour": 1.0, "min_area_rect": 0.75}[method]
        confidence = float(
            np.clip(base * (0.7 * _angle_score(ordered) + 0.3 * min(1.0, area_ratio * 1.6)), 0, 1)
        )

    log.info(
        "Detection: method=%s confidence=%.2f area=%.1f%%",
        method, confidence, area_ratio * 100,
    )
    return Detection(
        corners=(ordered * scale).astype("float32"),
        method=method,
        confidence=round(confidence, 3),
        area_ratio=round(area_ratio, 3),
    )


def draw_detection(image: np.ndarray, detection: Detection) -> np.ndarray:
    """Overlay the detected quadrilateral for visual debugging."""
    canvas = image.copy()
    if canvas.ndim == 2:
        canvas = cv2.cvtColor(canvas, cv2.COLOR_GRAY2BGR)
    pts = detection.corners.astype(np.int32).reshape(-1, 1, 2)
    cv2.polylines(canvas, [pts], True, (0, 200, 0), 4, cv2.LINE_AA)
    labels: List[str] = ["TL", "TR", "BR", "BL"]
    for (x, y), label in zip(detection.corners.astype(int), labels):
        cv2.circle(canvas, (int(x), int(y)), 12, (0, 0, 255), -1)
        cv2.putText(canvas, label, (int(x) + 16, int(y) - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2, cv2.LINE_AA)
    return canvas
