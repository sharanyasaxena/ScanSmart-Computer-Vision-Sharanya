"""Enhancement (Module 3).

Turns the flattened page into a readable, print-ready image. Three output
modes are supported, matching what commercial scanner apps offer.
"""

import cv2
import numpy as np

from .config import ScanConfig
from .exceptions import InvalidConfigError
from .logger import get_logger

log = get_logger(__name__)


def unsharp_mask(image: np.ndarray, amount: float) -> np.ndarray:
    """Classic unsharp masking: image + amount * (image - blurred)."""
    blurred = cv2.GaussianBlur(image, (0, 0), sigmaX=3)
    return cv2.addWeighted(image, 1 + amount, blurred, -amount, 0)


def remove_shadows(gray: np.ndarray) -> np.ndarray:
    """Flatten uneven illumination using morphological background division.

    Dilating with a large kernel estimates the page background; dividing the
    original by that background cancels shadows and lighting gradients.
    """
    kernel = np.ones((15, 15), np.uint8)
    dilated = cv2.dilate(gray, kernel)
    background = cv2.medianBlur(dilated, 21)
    diff = 255 - cv2.absdiff(gray, background)
    return cv2.normalize(diff, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8UC1)


def to_scan(image: np.ndarray, config: ScanConfig) -> np.ndarray:
    """Black-and-white 'photocopy' output via adaptive thresholding."""
    gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    flat = remove_shadows(gray)
    binary = cv2.adaptiveThreshold(
        flat, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,
        config.adaptive_block, config.adaptive_c,
    )
    # Remove isolated salt noise left by thresholding.
    return cv2.medianBlur(binary, 3)


def to_gray(image: np.ndarray, config: ScanConfig) -> np.ndarray:
    """Shadow-free, sharpened grayscale output."""
    gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    flat = remove_shadows(gray)
    clahe = cv2.createCLAHE(clipLimit=config.clahe_clip,
                            tileGridSize=(config.clahe_grid, config.clahe_grid))
    return unsharp_mask(clahe.apply(flat), config.sharpen_amount)


def to_color(image: np.ndarray, config: ScanConfig) -> np.ndarray:
    """Colour output with white balance and local contrast boost.

    CLAHE is applied to the L channel of LAB so that colours are untouched.
    """
    if image.ndim == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=config.clahe_clip,
                            tileGridSize=(config.clahe_grid, config.clahe_grid))
    merged = cv2.merge([clahe.apply(l), a, b])
    balanced = cv2.cvtColor(merged, cv2.COLOR_LAB2BGR)
    return unsharp_mask(balanced, config.sharpen_amount)


_DISPATCH = {"scan": to_scan, "gray": to_gray, "color": to_color}


def enhance(image: np.ndarray, config: ScanConfig) -> np.ndarray:
    """Apply the enhancement mode selected in the configuration."""
    handler = _DISPATCH.get(config.mode)
    if handler is None:                       # defensive - config validates too
        raise InvalidConfigError(f"Unknown enhancement mode: {config.mode}")
    log.debug("Applying enhancement mode '%s'", config.mode)
    return handler(image, config)
