"""Custom exception hierarchy for ScanSmart.

Using a dedicated hierarchy lets the CLI distinguish between a *recoverable*
failure (one bad image inside a batch) and a *fatal* failure (bad configuration)
without relying on generic exceptions.
"""


class ScanSmartError(Exception):
    """Base class for every error raised by ScanSmart."""


class ImageLoadError(ScanSmartError):
    """Raised when an image file cannot be read or decoded."""


class DocumentNotFoundError(ScanSmartError):
    """Raised when no document-like quadrilateral can be located."""


class InvalidConfigError(ScanSmartError):
    """Raised when the user supplies an inconsistent configuration."""


class ExportError(ScanSmartError):
    """Raised when results cannot be written to disk."""
