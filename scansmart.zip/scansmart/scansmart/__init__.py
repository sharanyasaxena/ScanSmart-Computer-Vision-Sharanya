"""
ScanSmart - Automatic Document Scanner & Image Enhancement System.

A classical computer-vision pipeline that locates a document inside a
photograph, removes perspective distortion and produces a clean,
scanner-quality output image.
"""

__version__ = "1.0.0"
__author__ = "ScanSmart Project"

from .config import ScanConfig
from .exceptions import (
    ScanSmartError,
    ImageLoadError,
    DocumentNotFoundError,
    InvalidConfigError,
)

__all__ = [
    "ScanConfig",
    "ScanSmartError",
    "ImageLoadError",
    "DocumentNotFoundError",
    "InvalidConfigError",
    "__version__",
]
