"""Geometric correction (Module 2b).

Removes perspective distortion by estimating the homography that maps the
detected quadrilateral onto an axis-aligned rectangle, then warping.
"""

from typing import Tuple

import cv2
import numpy as np

from .config import ScanConfig
from .detector import order_corners
from .logger import get_logger

log = get_logger(__name__)


def estimate_output_size(corners: np.ndarray, config: ScanConfig) -> Tuple[int, int]:
    """Derive the width/height of the flattened page from its corners.

    The two opposite edges of a perspective-distorted rectangle have
    different lengths; taking the maximum preserves detail.
    """
    tl, tr, br, bl = order_corners(corners)
    width = max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl))
    height = max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl))
    width, height = int(round(width)), int(round(height))
    width, height = max(width, 10), max(height, 10)

    longest = max(width, height)
    if longest > config.max_output_side:       # clamp huge outputs
        factor = config.max_output_side / float(longest)
        width, height = int(width * factor), int(height * factor)
    return width, height


def four_point_transform(image: np.ndarray, corners: np.ndarray,
                         config: ScanConfig) -> np.ndarray:
    """Warp the quadrilateral `corners` of `image` into a flat rectangle."""
    src = order_corners(corners)
    width, height = estimate_output_size(src, config)
    dst = np.array(
        [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
        dtype="float32",
    )
    matrix = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(
        image, matrix, (width, height), flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )
    log.debug("Warped to %dx%d", width, height)

    m = config.border_margin
    if m > 0 and warped.shape[0] > 2 * m and warped.shape[1] > 2 * m:
        warped = warped[m:-m, m:-m]
    return warped


def estimate_skew(gray: np.ndarray) -> float:
    """Estimate residual text skew (degrees) with the Hough line transform.

    Reported in the quality metrics so the user knows whether the page is
    still slightly rotated after warping.
    """
    edges = cv2.Canny(gray, 50, 150)
    lines = cv2.HoughLinesP(
        edges, 1, np.pi / 180, threshold=120, minLineLength=gray.shape[1] // 4,
        maxLineGap=20,
    )
    if lines is None:
        return 0.0
    angles = []
    for x1, y1, x2, y2 in lines[:, 0]:
        angle = np.degrees(np.arctan2(y2 - y1, x2 - x1))
        if -45 < angle < 45:                 # keep near-horizontal lines only
            angles.append(angle)
    return round(float(np.median(angles)), 2) if angles else 0.0


def deskew(image: np.ndarray, angle: float) -> np.ndarray:
    """Rotate the image by `-angle` about its centre."""
    if abs(angle) < 0.1:
        return image
    h, w = image.shape[:2]
    matrix = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, 1.0)
    return cv2.warpAffine(
        image, matrix, (w, h), flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )
