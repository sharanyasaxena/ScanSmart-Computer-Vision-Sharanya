"""Central configuration object.

Every tunable constant of the pipeline lives here so that the algorithm
modules stay free of magic numbers. The dataclass is validated on creation,
which satisfies the "validation and error handling" requirement.
"""

from dataclasses import dataclass, field, asdict
from typing import Tuple

from .exceptions import InvalidConfigError

MODES: Tuple[str, ...] = ("scan", "gray", "color")


@dataclass
class ScanConfig:
    """Tunable parameters for the whole scanning pipeline."""

    # ---- Pre-processing -------------------------------------------------
    working_height: int = 600          # height used for detection (speed)
    blur_kernel: int = 5               # Gaussian/bilateral kernel size (odd)
    bilateral_sigma: int = 30          # edge-preserving smoothing strength
    clahe_clip: float = 2.0            # contrast limited adaptive hist. eq.
    clahe_grid: int = 8

    # ---- Detection ------------------------------------------------------
    canny_sigma: float = 0.33          # auto-threshold spread around median
    morph_kernel: int = 5              # closing kernel to bridge edge gaps
    min_area_ratio: float = 0.12       # a document must cover >=12% of frame
    max_area_ratio: float = 0.99
    approx_eps_start: float = 0.01     # Douglas-Peucker epsilon sweep
    approx_eps_end: float = 0.08
    approx_eps_step: float = 0.005
    top_contours: int = 8              # how many contours to test

    # ---- Geometric correction ------------------------------------------
    max_output_side: int = 2000        # clamp warped output size
    border_margin: int = 0             # optional crop margin in px

    # ---- Enhancement ----------------------------------------------------
    mode: str = "scan"
    adaptive_block: int = 35           # adaptive threshold window (odd)
    adaptive_c: int = 12               # adaptive threshold constant
    sharpen_amount: float = 0.6        # unsharp-mask strength

    # ---- Quality / acceptance ------------------------------------------
    min_confidence: float = 0.25       # below this the result is flagged
    blur_threshold: float = 60.0       # Laplacian variance blur cut-off

    # ---- I/O ------------------------------------------------------------
    valid_extensions: Tuple[str, ...] = field(
        default_factory=lambda: (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff")
    )

    def __post_init__(self) -> None:
        self.validate()

    def validate(self) -> None:
        """Validate the configuration, raising InvalidConfigError if broken."""
        if self.mode not in MODES:
            raise InvalidConfigError(f"mode must be one of {MODES}, got {self.mode!r}")
        if self.blur_kernel % 2 == 0 or self.blur_kernel < 1:
            raise InvalidConfigError("blur_kernel must be a positive odd number")
        if self.adaptive_block % 2 == 0 or self.adaptive_block < 3:
            raise InvalidConfigError("adaptive_block must be an odd number >= 3")
        if not 0.0 < self.min_area_ratio < self.max_area_ratio <= 1.0:
            raise InvalidConfigError("area ratios must satisfy 0 < min < max <= 1")
        if self.working_height < 100:
            raise InvalidConfigError("working_height must be >= 100 px")
        if not 0.0 <= self.min_confidence <= 1.0:
            raise InvalidConfigError("min_confidence must lie in [0, 1]")

    def to_dict(self) -> dict:
        """Serialise the configuration (used in the JSON run report)."""
        return asdict(self)
